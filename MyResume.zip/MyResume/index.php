<?php 
include "config.php";  

$query = "SELECT * FROM portfolioSh.portfolio_yarden;";
$result = mysqli_query($connection,$query);

if(!$result){
  die("DB failure: " .mysqli_connect_errno()."");
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Yarden Ish-Shalom</title>
  <meta content="Shenkar - Engineering. Design. Art. Buisness Portfolio by Yarden Ish-Shalom." name="description">
  <meta content="Yarden Ish-Shalom as a Software Engineering Student at Shenkar as part of the Web ans Cloud Course by Yonit Rusho PhD" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <script src="https://kit.fontawesome.com/4954bb4271.js" crossorigin="anonymous"></script>
  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">


</head>

<body>

  <!-- ======= Mobile nav toggle button ======= -->
  <!-- <button type="button" class="mobile-nav-toggle d-xl-none"><i class="bi bi-list mobile-nav-toggle"></i></button> -->
  <i class="bi bi-list mobile-nav-toggle d-xl-none"></i>
  <!-- ======= Header ======= -->
  <header id="header" class="d-flex flex-column justify-content-center">

    <nav id="navbar" class="navbar nav-menu">
      <ul>
        <li><a href="#hero" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Home</span></a></li>
        <li><a href="#about" class="nav-link scrollto"><i class="bx bx-user"></i> <span>About</span></a></li>
        <li><a href="#services" class="nav-link scrollto"><i class="bx bx-server"></i> <span>Projects</span></a></li>
        <li><a href="#contact" class="nav-link scrollto"><i class="fa-solid fa-envelope-open-text"></i> <span>Contact</span></a></li>
      </ul>
    </nav><!-- .nav-menu -->

  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center">
    <div class="container" data-aos="zoom-in" data-aos-delay="100">
      <h1>Yarden Ish-Shalom</h1>
      <p>I'm <span class="typed" data-typed-items="A Gamer, A Developer, A Student, Creative"></span></p>
      <div class="social-links">
        
        
        
        <a href="https://github.com/YardenIS388" class="github"><i class="bx bxl-github"></i></a>
        <a href="https://www.linkedin.com/in/yarden-ish-shalom-6b4508b3/" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>About</h2>
         
        </div>

        <div class="row">
          <div class="col-lg-4" style="padding:2px;">
            <img src="assets/img/about_photo.png" class="img-fluid gap-1" alt="Personal Portrait">
          </div>
          <div class="col-lg-8 pt-4 pt-lg-0 content align-middle">
            
           
            <section id="skills" class="skills section-bg">
              <div class="container" data-aos="fade-up">
        
                <div class="section-title text-start">
                  <h3>What I Love Doing</h3>
                  <p>I am lucky enough to be able to do what I love. These are my strongest skiils.</p>
                </div>
        
                <div class="row">
        
                  <div class="d-grid gap-2 col-6">
                    <button type="button" class="btn btn-outline-secondary btn-md p-2 ">HTML <i class="fa-solid fa-code"></i></i></button>
                    <button type="button" class="btn btn-outline-secondary btn-md ">CSS <i class="fa-solid fa-palette"></i></button>
                    <button type="button" class="btn btn-outline-secondary btn-md ">JavaScript <i class="fa-brands fa-js-square"></i></button>
                  </div>
        
                  <div class="d-grid gap-2 col-6">
                    <button type="button" class="btn btn-outline-secondary btn-md ">PHP <i class="fa-brands fa-php"></i></button>
                    <button type="button" class="btn btn-outline-secondary btn-md ">C/C++ <i class="fa-solid fa-computer-classic"></i></button>
                    <button type="button" class="btn btn-outline-secondary btn-md ">MySQL <i class="fa-solid fa-database"></i></button>
                  </div>
        
                </div>

               
              </div>
            </section><!-- End Skills Section -->

            <div class="d-flex p-2 bd-highlight justify-content-end container ">
                  <a href="assets/Yarden_Ish_Shalom_-_Software_Engineer.pdf" target="_blank">
                  <button type="button" class="btn btn-outline-primary btn-md text-end m-3">Take A Look At My Resume</button>
                </a>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

   

    <!-- ======= Skills Section ======= -->
   

    <!-- ======= Resume Section ======= -->
   

 

    <!-- ======= Projects Section ======= -->
    <section id="services" class="services">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Projects</h2>
          <p>These are the projects I have been working on ever since I started my software engineering degree </p>
        </div>

        <div class="row">
  <!-- this is the php logic to load the projects from db -->

          <?php 
          while($row = mysqli_fetch_assoc($result)){
                $name = $row["name"];
                $url = $row["url"];
                $description = $row["description"];
                $icon = $row["icon"];
                $project_id = $row["project_id"];
                echo '
                <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
                <div class="icon-box iconbox-blue">
                  <div class="icon">
                    <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                      <path stroke="none" stroke-width="0" fill="#f5f5f5" d="M300,521.0016835830174C376.1290562159157,517.8887921683347,466.0731472004068,529.7835943286574,510.70327084640275,468.03025145048787C554.3714126377745,407.6079735673963,508.03601936045806,328.9844924480964,491.2728898941984,256.3432110539036C474.5976632858925,184.082847569629,479.9380746630129,96.60480741107993,416.23090153303,58.64404602377083C348.86323505073057,18.502131276798302,261.93793281208167,40.57373210992963,193.5410806939664,78.93577620505333C130.42746243093433,114.334589627462,98.30271207620316,179.96522072025542,76.75703585869454,249.04625023123273C51.97151888228291,328.5150500222984,13.704378332031375,421.85034740162234,66.52175969318436,486.19268352777647C119.04800174914682,550.1803526380478,217.28368757567262,524.383925680826,300,521.0016835830174"></path>
                    </svg>
                    <i class="'.$icon.'"></i>
                  </div>
                  <h4><a href="project.php?prodId='.$project_id.'">'.$name.'</a></h4>
                  <p>'.$description.'</p>
                </div>
              </div>
              ';
          }

          mysqli_free_result($result);
              
          ?>
        </div>

      </div>
    </section><!-- End Projects Section -->

    <!-- Start Contact me section -->
  <section id = "contact">
      <div class="container" data-aos="fade-up">
          <div class="section-title">
                <h2>Contact</h2>
          </div>    

            <div class="row">
                <div class="card mx-auto" style="width: 80%;">
                
                <div class="card-body">
                <h5 class="card-title mx-auto"> <i class="fa-solid fa-paper-plane"></i> Contact Information </h5>
                <p class="card-text row">
                  <span>
                    <p>Email: yard48@gmail.com</p>
                  </span>
                  <span>
                    <p>Phone Number: +972508284533</p>
                  </span>
                </p>
                <div class="social-links">
       <span>Social Media:</span>
        <a href="https://github.com/YardenIS388" class="google-plus"><i class="bx bxl-github"></i></a>
        <a href="https://www.linkedin.com/in/yarden-ish-shalom-6b4508b3/" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
            </div>
</div>
          </div>
      </div>  
  </section>

 

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container mx-auto">
      <h5>Yarden Ish-Shalom</h5>
      <p>Let's Interact </p>
      <div class="social-links">
       
        <a href="https://github.com/YardenIS388" class="google-plus"><i class="bx bxl-github"></i></a>
        <a href="https://www.linkedin.com/in/yarden-ish-shalom-6b4508b3/" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
      <div class="copyright">
        <a href="https://www.shenkar.ac.il/he/departments/engineering-software-department">
          תואר ראשון בהנדסת תוכנה בשנקר

        </a>
      </div>
      <div class="copyright">
        &copy; Copyright <strong><span>MyResume</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: [license-url] -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/free-html-bootstrap-template-my-resume/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/typed.js/typed.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
    <?php 
      mysqli_close($connection);
    ?>
</body>

</html>